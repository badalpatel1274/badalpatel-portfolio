// import React, { useState } from "react";
// import img3 from "./images/img3.jpg";
// import img4 from "./images/img4.jpeg";
// import img1 from './images/img1.jpg';
// import img2 from './images/img2.jpg';
// import img3 from './images/img3.jpg';
// import img4 from './images/img4.jpeg';


// function Gallary() {
//  const [images setImages] =useState([
//    images :
//     {
//       id:1,
//       pic:img1,
//       type:"nature"
//     },
//     {
//       id:2,
//       pic:img2,
//       type:"animal"
//     },
//     {
//       id:3,
//       pic:img3,
//       type:"animal"
//     },
//     {
//       id:4,
//       pic:img4,
//       type:"nature"
//     },
//   ]);
//   function natureImage(category) {
//     images = images.filter((value) => {
//       if (value.type == category) {
//         return true;
//       } else return false;
//     });
//     setImage(images);
//   }
//   function animalImage(category) {
//     images = images.filter((value) => {
//       if (value.type == category) {
//         return true;
//       } else return false;
//     });
//     setImage(images);
//   }

//   return (
    
//     <div>
//       <div>
//         <button>ALL</button>
//         <button onClick={()=>natureImage("nature")}>Nature</button>
//          <button onClick={()=>animalImage("animal")}>Animal</button>

//       </div>
      
//             {images.map((value) => (
//      <img src={value.pic} height="400px" width="300px"></img>
//             ))}
      
//     </div>
//   );
// }

// export default Gallary;
// import logo from "./images/n4.avif";
// import badal from "./images/badal.jpeg";
// import a from "./images/a2.webp";
// import html from "./images/ht.png";
// import css from "./images/css.png";
// import jq from "./images/jq.png";
// import boot from "./images/boot.jpeg";
// import js from "./images/js.png";
// import re from "./images/re.svg";
// import bk from "./images/bk.jpg";