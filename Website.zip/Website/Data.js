// import React, { useState } from 'react';
// import img1 from './images/img1.jpg';
// import img2 from './images/img2.jpg';
// import img3 from './images/img3.jpg';
// import img4 from './images/img4.jpeg';
// import Gallary from './Gallary'
// function Data() {


// const [allImages, setAllImages] = useState(
//   {
//     id:1,
//     pic:img1,
//     type:"nature"
//   },
//   {
//     id:2,
//     pic:img2,
//     type:"animal"
//   },
//   {
//     id:3,
//     pic:img3,
//     type:"animal"
//   },
//   {
//     id:4,
//     pic:img4,
//     type:"nature"
//   },

// )
  
// function natureImage(nature) {
//     allImages = allImages.filter((value) => {
//       if (value.type == nature) {
//         return true;
//       } else return false;
//     });
//     setAllImage(allImages);
//   }
//   function animalImage(animal) {
//     allImages = allImages.filter((value) => {
//       if (value.type == animal) {
//         return true;
//       } else return false;
//     });
//     setAllImage(allImages);
//   }






//   return (
//     <div>
//       <Gallary/>
// <center>
//   <h1> <b>Art Gallery</b></h1>
// </center>
// <button onClick={allImages}>All</button>
// <button onClick={()=>natureImage("nature")}>Nature</button>
// <button onClick={()=>animalImage("animal")}>Animal</button>
// <div>

// {allImages.map((value) => (
//   <img src={value.pic} height="400px" width="300px"></img>
// ))}
// </div>
      

//     </div>
//   )
// }

// export default Data