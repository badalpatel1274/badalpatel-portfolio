// import React, { useState } from 'react';
// import img1 from './images/img1.jpg';
// import img2 from './images/img2.jpg';
// import img3 from './images/img3.jpg';
// import img4 from './images/img4.jpeg';

// function All() {
//     const [allpic, setAllpic]=useState({i1:img1, i2:img2, i3:img3, i4:img4 } )
//     function animal(){
//         setAllpic({i3:img3})
//     }
//     function nature(){
//         setAllpic({i4:img4})
//     }
//     function crickter(){
//         setAllpic({i1:img1})
//     }
//     function actor(){
//         setAllpic({i2:img2})
//     }
//     function all(){
//         setAllpic({
//             i1:img1,
//             i2:img2,
//             i3:img3,
//             i4:img4
//         })
//     }
//   return (
//     <div>
//         <div>
//             <button onClick={all}>All</button>
// <button onClick={animal} >Animal</button>
// <button onClick={nature}>Nature</button>
// <button onClick={crickter}>Crickter</button>
// <button onClick={actor}>Actor</button>


//         </div>
//         <div className='img'>

// <img src={allpic.i1}></img>
// <img src={allpic.i2}></img>
// <img src={allpic.i3}></img>
// <img src={allpic.i4}></img>
//         </div>




//     </div>
//   )
// }

// export default All