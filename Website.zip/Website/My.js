import React from "react";
import { Link } from "react-scroll";
import badal from "./images/badal.jpeg";
import a from "./images/a2.webp";
import html from "./images/ht.png";
import css from "./images/css.png";
import jq from "./images/jq.png";
import boot from "./images/boot.jpeg";
import js from "./images/js.png";
import re from "./images/re.svg";
import bk from "./images/bk.jpg";
function My() {
  return (
    <div>
      {/* navbar */}
      <div>
        <nav className="Navbar">
          <div class="cta">
            <img src={bk}></img>
          </div>
          <ul className="link">
            
            <Link to={"firstComponent"} smooth={true} duration={500}>
              <p>Home</p>
            </Link>

            {/* </Link> */}
            <Link to={"about"} smooth={true} duration={500}>
              <p>About</p>
            </Link>

            <Link to={"service"} smooth={true} duration={500}>
              <p>Skills</p>
            </Link>
            <Link to={"footer"} smooth={true} duration={500}>
              <p>Contact</p>
            </Link>
          </ul>
        </nav>
      </div>

      <div id="firstComponent" className="name d-flex j-c-between">
        <p>
          <h1 style={{fontSize:"55px"}}>
            <b>Badal Patel</b>
          </h1>
          <h4>Computer Engineer</h4>
          <h5>(Developer)</h5>
        </p>
        <div className='pic'>
        <img src={badal} className="bg" style={{ width: "400px", height: "400px" , borderRadius:"50%", }}></img>
      </div>
        </div>

      <div id="about" className="p2">
        <img src={a} height={340}></img>

        <div className="text-part">
          <h1>
            <b>About Me</b>
          </h1>
          <h2>Hi, I'm Badal. I am a Frontend Developer, using language like,
            Html,CSS,Bootstrap, React etc..</h2>
        </div>
      </div>

      <div id="service" className="service">
        <h1 className="ski"><i>Skills</i></h1>
        <div className="row d-flex">
          <div className="col-4">
            <div className="box">
              <img src={html} style={{ width: "100px", height: "80px" }}></img>

              <h1>Html</h1>
            </div>
          </div>
          <div className="col-4">
            <div className="box">
              <img src={css} style={{ width: "100px", height: "80px" }}></img>

              <h1>CSS</h1>
            </div>
          </div>
          <div className="col-4">
            <div className="box">
              <img src={jq} style={{ width: "100px", height: "80px" }}></img>

              <h1>JQUERY</h1>
            </div>
          </div>
        </div>
        <div className="row d-flex">
          <div className="col-4">
            <div className="box">
              <img src={boot} style={{ width: "100px", height: "80px" }}></img>

              <h1>Bootstrap</h1>
            </div>
          </div>
          <div className="col-4">
            <div className="box">
              <img src={js} style={{ width: "100px", height: "80px" }}></img>

              <h1>Javascript</h1>
            </div>
          </div>
          <div className="col-4">
            <div className="box">
              <img src={re} style={{ width: "100px", height: "80px" }}></img>

              <h1>React</h1>
            </div>
          </div>
        </div>
      </div>

      {/* PAGE 4 */}
      <div className="page4">
        <div className="client">
          <h1 className="ski"><i>Client Testimonials</i></h1>
        </div>

        <div className="badal">
          <h2>"My website improved so much after Badal did his Magic. "</h2>
          <h3>-Badal Patel</h3>
        </div>

        <div className="very d-flex j-c-between">
          <div className="very1">
            <h2>Meet Patel</h2>
            <p>
              Badal is very professional and easy to work <br></br> with. His
              work is exceptional."
            </p>
          </div>
          <div className="very2">
            <h2>Abhi Patel</h2>
            <p>
              Badal knows what he's doing. He has helped <br></br> our business
              so much."
            </p>
          </div>
        </div>
      </div>

      {/* PAGE 5 */}

      <div id="footer" className="footer d-flex j-c-between">
        <div className="footer1">
          <h1>Get in touch.</h1>
          <h3>
            Drop me a line or two if you want to <br></br> work together!
          </h3>
          <p>9510240294</p>
          <p>badalpatel31628@gmail.com</p>
        </div>
        <div className="footer2">
          <img src="https://img.freepik.com/free-photo/creative-people-working-office_23-2147656715.jpg?size=626&ext=jpg&ga=GA1.1.66533755.1720161496&semt=ais_hybrid"></img>
        </div>
      </div>

      {/* footer */}

      <footer class="f1">
        <p>Thank you for visiting our website!</p>
      </footer>
    </div>
  );
}

export default My;
